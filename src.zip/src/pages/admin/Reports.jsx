import { useEffect, useMemo, useState } from "react";
import { db } from "../../lib/firebase/config";
import {
  collection,
  query,
  where,
  orderBy,
  getDocs,
} from "firebase/firestore";
import { useAuth } from "../../contexts/AuthContext";

function formatMoney(val) {
  if (val === null || val === undefined) return "—";
  return `LKR ${Number(val).toLocaleString()}`;
}

function getDateRange(filter) {
  const now = new Date();

  if (filter === "7") {
    return new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
  }

  if (filter === "30") {
    return new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
  }

  return null; // all time
}

export default function Dashboard() {
  const { user } = useAuth();

  const [sales, setSales] = useState([]);
  const [loading, setLoading] = useState(true);
  const [range, setRange] = useState("all");

  useEffect(() => {
    if (!user?.uid) return;

    const loadSales = async () => {
      setLoading(true);

      const q = query(
        collection(db, "sales"),
        where("userId", "==", user.uid),
        orderBy("soldAt", "desc")
      );

      const snap = await getDocs(q);
      const data = snap.docs.map((d) => ({
        id: d.id,
        ...d.data(),
      }));

      setSales(data);
      setLoading(false);
    };

    loadSales();
  }, [user]);

  const filteredSales = useMemo(() => {
    const cutoff = getDateRange(range);
    if (!cutoff) return sales;

    return sales.filter(
      (s) => new Date(s.soldAt?.seconds * 1000) >= cutoff
    );
  }, [sales, range]);

  const summary = useMemo(() => {
    let revenue = 0;
    let cost = 0;
    let profit = 0;

    filteredSales.forEach((s) => {
      revenue += Number(s.sellingPrice || 0);
      cost += Number(s.costPrice || 0);
      profit += Number(s.profit || 0);
    });

    return {
      revenue,
      cost,
      profit,
      count: filteredSales.length,
    };
  }, [filteredSales]);

  const last10 = filteredSales.slice(0, 10);

  const exportCSV = () => {
    const rows = [
      [
        "Date",
        "Stone",
        "Code",
        "Cost",
        "Selling Price",
        "Expenses",
        "Profit",
      ],
    ];

    filteredSales.forEach((s) => {
      rows.push([
        new Date(s.soldAt?.seconds * 1000).toLocaleDateString(),
        s.stoneName,
        s.stoneCode,
        s.costPrice,
        s.sellingPrice,
        s.expenses,
        s.profit,
      ]);
    });

    const csv = rows.map((r) => r.join(",")).join("\n");

    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);

    const a = document.createElement("a");
    a.href = url;
    a.download = "facetvault-sales.csv";
    a.click();
  };

  return (
    <div className="p-5 text-white">
      <h1 className="mb-6 text-2xl font-semibold">Dashboard</h1>

      {/* FILTERS */}
      <div className="mb-6 flex gap-2">
        {[
          { key: "all", label: "All Time" },
          { key: "7", label: "Last 7 Days" },
          { key: "30", label: "Last 30 Days" },
        ].map((f) => (
          <button
            key={f.key}
            onClick={() => setRange(f.key)}
            className={`rounded-xl px-3 py-1 text-sm ${
              range === f.key
                ? "bg-amber-400 text-black"
                : "bg-white/10"
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* SUMMARY */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <div className="rounded-xl bg-white/5 p-4">
          <p className="text-xs text-white/50">Revenue</p>
          <p className="text-lg font-semibold">
            {formatMoney(summary.revenue)}
          </p>
        </div>

        <div className="rounded-xl bg-white/5 p-4">
          <p className="text-xs text-white/50">Cost</p>
          <p className="text-lg font-semibold">
            {formatMoney(summary.cost)}
          </p>
        </div>

        <div className="rounded-xl bg-white/5 p-4">
          <p className="text-xs text-white/50">Profit</p>
          <p className="text-lg font-semibold text-emerald-400">
            {formatMoney(summary.profit)}
          </p>
        </div>

        <div className="rounded-xl bg-white/5 p-4">
          <p className="text-xs text-white/50">Sales</p>
          <p className="text-lg font-semibold">
            {summary.count}
          </p>
        </div>
      </div>

      {/* EXPORT */}
      <div className="mt-6">
        <button
          onClick={exportCSV}
          className="rounded-xl bg-amber-400 px-4 py-2 text-black"
        >
          Download Report (CSV)
        </button>
      </div>

      {/* LAST 10 SALES */}
      <div className="mt-8">
        <h2 className="mb-3 text-lg font-semibold">
          Recent Sales
        </h2>

        {loading ? (
          <p className="text-white/50">Loading...</p>
        ) : last10.length === 0 ? (
          <p className="text-white/50">No sales yet</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-left text-white/50">
                <tr>
                  <th>Date</th>
                  <th>Stone</th>
                  <th>Code</th>
                  <th>Cost</th>
                  <th>Sold</th>
                  <th>Profit</th>
                </tr>
              </thead>
              <tbody>
                {last10.map((s) => (
                  <tr key={s.id} className="border-t border-white/10">
                    <td>
                      {new Date(
                        s.soldAt?.seconds * 1000
                      ).toLocaleDateString()}
                    </td>
                    <td>{s.stoneName}</td>
                    <td>{s.stoneCode}</td>
                    <td>{formatMoney(s.costPrice)}</td>
                    <td>{formatMoney(s.sellingPrice)}</td>
                    <td className="text-emerald-400">
                      {formatMoney(s.profit)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}