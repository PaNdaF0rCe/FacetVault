import { useEffect, useMemo, useState } from "react";
import { getPublicSaleInventory } from "../lib/firebase/inventory-operations";
import {
  CONTACT_PHONE,
  WHATSAPP_MESSAGE,
  WHATSAPP_NUMBER,
} from "../config/appConfig";

function formatMoney(value) {
  if (value === null || value === undefined || value === "") {
    return "Price on request";
  }

  const num = Number(value);
  if (Number.isNaN(num)) return "Price on request";

  return `LKR ${num.toLocaleString()}`;
}

function buildWhatsAppLink(item) {
  const baseMessage =
    WHATSAPP_MESSAGE || "Hello, I'm interested in this gemstone.";
  const gemName = item?.name ? ` Gem: ${item.name}.` : "";
  const message = `${baseMessage}${gemName}`.trim();

  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}

function SaleBadge() {
  return (
    <span className="inline-flex items-center rounded-full border border-emerald-400/20 bg-emerald-400/10 px-3 py-1 text-[11px] font-medium uppercase tracking-[0.16em] text-emerald-300">
      Available
    </span>
  );
}

function DetailChip({ children }) {
  if (!children) return null;

  return (
    <span className="rounded-full border border-white/10 px-3 py-1 text-xs text-gray-300">
      {children}
    </span>
  );
}

function MarketplaceCard({ item, phoneRevealed, onRevealPhone }) {
  const hasWhatsApp = !!WHATSAPP_NUMBER;
  const hasPhone = !!CONTACT_PHONE;
  const whatsappLink = buildWhatsAppLink(item);

  return (
    <article className="overflow-hidden rounded-3xl border border-white/10 bg-[#020617]/95 shadow-[0_14px_34px_rgba(0,0,0,0.22)] transition hover:-translate-y-0.5 hover:border-amber-400/40">
      <div className="aspect-square w-full overflow-hidden bg-[#04101f]">
        {item.imageUrl ? (
          <img
            src={item.imageUrl}
            alt={item.name || "Gemstone"}
            className="h-full w-full object-cover"
            loading="lazy"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center text-sm text-gray-500">
            No image available
          </div>
        )}
      </div>

      <div className="space-y-4 p-5">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <h2 className="truncate text-xl font-semibold text-white">
              {item.name || "Untitled Gem"}
            </h2>
            <p className="mt-1 text-sm text-gray-400">
              {item.stoneType || item.category || "Gemstone"}
            </p>
          </div>

          <SaleBadge />
        </div>

        <div className="flex flex-wrap gap-2">
          <DetailChip>{item.category}</DetailChip>
          <DetailChip>{item.color}</DetailChip>
          <DetailChip>{item.cut}</DetailChip>
          <DetailChip>{item.origin}</DetailChip>
          <DetailChip>
            {item.carat !== null &&
            item.carat !== undefined &&
            item.carat !== ""
              ? `${item.carat} ct`
              : null}
          </DetailChip>
        </div>

        {item.notes ? (
          <p className="line-clamp-3 text-sm leading-6 text-gray-400">
            {item.notes}
          </p>
        ) : null}

        <div className="rounded-2xl border border-amber-400/15 bg-amber-400/10 px-4 py-3">
          <p className="text-xs uppercase tracking-[0.18em] text-amber-300/80">
            Selling Price
          </p>
          <p className="mt-1 text-xl font-semibold text-amber-300">
            {formatMoney(item.salePrice)}
          </p>
        </div>

        {!phoneRevealed ? (
          <button
            type="button"
            onClick={() => onRevealPhone(item.id)}
            className="w-full rounded-2xl bg-amber-400 px-4 py-3 text-sm font-semibold text-black transition hover:bg-amber-300"
          >
            Contact Me
          </button>
        ) : hasPhone ? (
          hasWhatsApp ? (
            <a
              href={whatsappLink}
              target="_blank"
              rel="noreferrer"
              className="block w-full rounded-2xl border border-white/10 px-4 py-3 text-center text-sm font-semibold text-white transition hover:border-white/20 hover:bg-white/5"
            >
              {CONTACT_PHONE}
            </a>
          ) : (
            <div className="w-full rounded-2xl border border-white/10 px-4 py-3 text-center text-sm font-semibold text-white">
              {CONTACT_PHONE}
            </div>
          )
        ) : (
          <div className="w-full rounded-2xl border border-white/10 px-4 py-3 text-center text-sm text-gray-300">
            Contact number not configured yet
          </div>
        )}

        {phoneRevealed && hasWhatsApp && (
          <p className="text-center text-xs text-gray-500">
            Click the number to open WhatsApp
          </p>
        )}
      </div>
    </article>
  );
}

function Marketplace() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [revealedPhones, setRevealedPhones] = useState({});
  const [search, setSearch] = useState("");

  useEffect(() => {
    let mounted = true;

    const loadItems = async () => {
      try {
        const data = await getPublicSaleInventory();
        if (mounted) {
          setItems(Array.isArray(data) ? data : []);
        }
      } catch (error) {
        console.error("Failed to load public sale inventory:", error);
        if (mounted) {
          setItems([]);
        }
      } finally {
        if (mounted) {
          setLoading(false);
        }
      }
    };

    loadItems();

    return () => {
      mounted = false;
    };
  }, []);

  const filteredItems = useMemo(() => {
    const term = search.trim().toLowerCase();
    if (!term) return items;

    return items.filter((item) => {
      return (
        (item.name || "").toLowerCase().includes(term) ||
        (item.stoneType || "").toLowerCase().includes(term) ||
        (item.category || "").toLowerCase().includes(term) ||
        (item.color || "").toLowerCase().includes(term) ||
        (item.cut || "").toLowerCase().includes(term) ||
        (item.origin || "").toLowerCase().includes(term)
      );
    });
  }, [items, search]);

  const handleRevealPhone = (itemId) => {
    setRevealedPhones((prev) => ({
      ...prev,
      [itemId]: true,
    }));
  };

  return (
    <div className="space-y-5 sm:space-y-6">
      <section className="rounded-3xl border border-white/10 bg-[linear-gradient(180deg,rgba(7,18,36,0.78),rgba(4,14,30,0.72))] p-5 shadow-[0_18px_50px_rgba(0,0,0,0.22)] backdrop-blur sm:p-6">
        <p className="text-[11px] font-medium uppercase tracking-[0.28em] text-amber-400/80 sm:text-xs">
          Public Collection
        </p>

        <h1 className="mt-2 text-3xl font-semibold tracking-tight text-amber-300 sm:text-4xl">
          Gemstones Available for Sale
        </h1>

        <p className="mt-2 max-w-2xl text-sm leading-6 text-gray-400 sm:text-base">
          Browse the stones currently listed for sale. Only publicly available
          items appear here.
        </p>

        <div className="mt-5 max-w-md">
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by name, type, color, cut, or origin"
            className="w-full rounded-2xl border border-white/10 bg-[#020617] px-4 py-3 text-sm text-white placeholder-gray-500 outline-none transition focus:border-amber-400"
          />
        </div>
      </section>

      {loading ? (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
          {Array.from({ length: 6 }).map((_, index) => (
            <div
              key={index}
              className="animate-pulse overflow-hidden rounded-3xl border border-white/10 bg-[#020617]/95"
            >
              <div className="aspect-square bg-white/5" />
              <div className="space-y-3 p-5">
                <div className="h-6 w-1/2 rounded bg-white/5" />
                <div className="h-4 w-1/3 rounded bg-white/5" />
                <div className="h-20 rounded bg-white/5" />
                <div className="h-12 rounded-2xl bg-white/5" />
              </div>
            </div>
          ))}
        </div>
      ) : filteredItems.length === 0 ? (
        <section className="rounded-3xl border border-white/10 bg-[#020617]/90 p-8 text-center shadow-[0_18px_50px_rgba(0,0,0,0.2)]">
          <h2 className="text-xl font-semibold text-white">
            No gemstones found
          </h2>
          <p className="mt-2 text-sm text-gray-400">
            There are no public sale items matching your search right now.
          </p>
        </section>
      ) : (
        <>
          <div className="flex items-center justify-between px-1">
            <p className="text-sm text-gray-400">
              {filteredItems.length} item
              {filteredItems.length === 1 ? "" : "s"} available
            </p>
          </div>

          <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
            {filteredItems.map((item) => (
              <MarketplaceCard
                key={item.id}
                item={item}
                phoneRevealed={!!revealedPhones[item.id]}
                onRevealPhone={handleRevealPhone}
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
}

export default Marketplace;